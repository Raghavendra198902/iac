# CMDB Agent - System Flow Chart

## 🔄 High-Level Agent Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                         CMDB Agent                                │
│                        (Main Process)                             │
└──────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌──────────────────────────────────────────┐
        │     Configuration Loader                  │
        │  - Read config.yaml                       │
        │  - Validate settings                      │
        │  - Apply defaults                         │
        └──────────────┬───────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────────────────┐
        │     Component Initialization              │
        │  1. Logger                                │
        │  2. Queue (BoltDB)                        │
        │  3. Transport (HTTP Client)               │
        │  4. Collectors Manager                    │
        │  5. Enforcement Engine                    │
        │  6. Deployment Manager                    │
        │  7. API Server (UNIX Socket)              │
        │  8. Web UI Server (HTTP)                  │
        └──────────────┬───────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────────┐
│                     Agent Main Loop                               │
└──────────────────────────────────────────────────────────────────┘
        │
        ├─────────────────────────────────────────────────────────┐
        │                                                           │
        ▼                                                           ▼
┌───────────────────┐                                    ┌──────────────────┐
│  Collector        │                                    │  Queue Processor │
│  Scheduler        │                                    │  (Background)    │
│  (Cron-based)     │                                    └─────────┬────────┘
└───────┬───────────┘                                              │
        │                                                           │
        │  Triggers at intervals                                   │
        │  (@every 30s, @every 1m, etc.)                          │
        ▼                                                           ▼
┌───────────────────┐                                    ┌──────────────────┐
│  Run Collectors   │                                    │  Pop Batch       │
│  - System         │                                    │  from Queue      │
│  - Hardware       │                                    │  (30s interval)  │
│  - Network        │                                    └─────────┬────────┘
│  - Software       │                                              │
│  - Services       │                                              │
│  - Process        │                                              ▼
│  - User           │                                    ┌──────────────────┐
│  - Certificate    │                                    │  Send to Backend │
└───────┬───────────┘                                    │  via Transport   │
        │                                                 │  (HTTPS + retry) │
        │  Collect Data                                  └─────────┬────────┘
        ▼                                                           │
┌───────────────────┐                                              │
│  Format as JSON   │                                              │
└───────┬───────────┘                                              │
        │                                                           │
        ▼                                                           │
┌───────────────────┐                                              │
│  Enqueue Data     │──────────────────────────────────────────────┘
│  to BoltDB Queue  │
└───────────────────┘
        │
        │
        ▼
┌───────────────────┐
│  Persist to Disk  │
│  (Survives crash) │
└───────────────────┘
```

---

## 🔐 Authentication & Authorization Flow

```
HTTP Request to Web UI
        │
        ▼
┌──────────────────┐
│  Check Auth      │
│  Header          │
└────────┬─────────┘
         │
         ▼
  ┌─────────────┐
  │ Has "Basic" │ ───No──→ Return 401 Unauthorized
  │  Auth?      │          + WWW-Authenticate header
  └──────┬──────┘
         │ Yes
         ▼
┌──────────────────┐
│  Decode Base64   │
│  Extract         │
│  username:pass   │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Lookup User     │
│  in Auth Store   │
└────────┬─────────┘
         │
    ┌────┴────┐
    │  Found? │──No──→ Return 401 "Invalid credentials"
    └────┬────┘
         │ Yes
         ▼
┌──────────────────┐
│  Compare Bcrypt  │
│  Password Hash   │
└────────┬─────────┘
         │
    ┌────┴─────┐
    │  Match?  │──No──→ Return 401 "Invalid credentials"
    └────┬─────┘
         │ Yes
         ▼
┌──────────────────┐
│  Load User Role  │
│  (Admin/Operator │
│   /Viewer)       │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Check Required  │
│  Permission for  │
│  Endpoint        │
└────────┬─────────┘
         │
    ┌────┴─────────┐
    │  Has Perm?   │──No──→ Return 403 "Forbidden"
    └────┬─────────┘
         │ Yes
         ▼
┌──────────────────┐
│  Add User to     │
│  Request Context │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Execute Handler │
│  (API endpoint)  │
└──────────────────┘
```

---

## 📊 Data Collection Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    Collection Trigger                        │
│  - Scheduled (cron)                                          │
│  - Manual (API/CLI)                                          │
│  - Event-driven (future)                                     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
          ┌──────────────────┐
          │  Select Collector │
          │  by Name          │
          └─────────┬─────────┘
                    │
       ┌────────────┼────────────┐
       │            │            │
       ▼            ▼            ▼
┌──────────┐ ┌──────────┐ ┌──────────┐
│ System   │ │ Hardware │ │ Software │  ... (8 collectors)
│ Collector│ │ Collector│ │ Collector│
└────┬─────┘ └────┬─────┘ └────┬─────┘
     │            │            │
     │            │            │
     └────────────┼────────────┘
                  │
                  ▼
         ┌────────────────┐
         │  Execute       │
         │  Collect()     │
         │  Method        │
         └────────┬───────┘
                  │
      ┌───────────┼───────────┐
      │           │           │
      ▼           ▼           ▼
┌──────────┐ ┌──────────┐ ┌──────────┐
│ OS Calls │ │ gopsutil │ │ File I/O │
│          │ │  Library │ │          │
└────┬─────┘ └────┬─────┘ └────┬─────┘
     │            │            │
     │  hostname  │  CPU info  │  /proc/*
     │  uname     │  Memory    │  dpkg -l
     │  uptime    │  Disk      │  rpm -qa
     │            │            │
     └────────────┼────────────┘
                  │
                  ▼
         ┌────────────────┐
         │  Aggregate     │
         │  Data          │
         └────────┬───────┘
                  │
                  ▼
         ┌────────────────┐
         │  Format JSON   │
         │  Structure:    │
         │  {             │
         │    type: "...", │
         │    timestamp,  │
         │    hostname,   │
         │    data: {...} │
         │  }             │
         └────────┬───────┘
                  │
                  ▼
         ┌────────────────┐
         │  Add Metadata  │
         │  - Agent ver   │
         │  - Collection  │
         │    mode        │
         │  - Tags        │
         └────────┬───────┘
                  │
                  ▼
         ┌────────────────┐
         │  Enqueue to    │
         │  BoltDB Queue  │
         └────────┬───────┘
                  │
                  ▼
         ┌────────────────┐
         │  Log Success   │
         │  or Error      │
         └────────────────┘
```

---

## 🚀 Queue Processing & Transport Flow

```
┌─────────────────────────────────────────────────────────────┐
│              Queue Processor (Every 30s)                     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
         ┌───────────────────┐
         │  Check Queue      │
         │  Has Items?       │
         └─────────┬─────────┘
                   │
              ┌────┴────┐
              │  Empty? │───Yes──→ Sleep 30s
              └────┬────┘
                   │ No
                   ▼
         ┌───────────────────┐
         │  Pop Batch        │
         │  (max 50 items or │
         │   512 KB)         │
         └─────────┬─────────┘
                   │
                   ▼
         ┌───────────────────┐
         │  Compress Data    │
         │  (gzip)           │
         └─────────┬─────────┘
                   │
                   ▼
         ┌───────────────────┐
         │  Add Auth         │
         │  - mTLS cert      │
         │  - OAuth2 token   │
         └─────────┬─────────┘
                   │
                   ▼
         ┌───────────────────┐
         │  HTTP POST to     │
         │  Backend API      │
         │  /api/v1/ci       │
         └─────────┬─────────┘
                   │
           ┌───────┴────────┐
           │                │
           ▼                ▼
    ┌──────────┐      ┌──────────┐
    │ Success? │      │  Error?  │
    │ (200 OK) │      │ (timeout,│
    └────┬─────┘      │  5xx)    │
         │            └────┬─────┘
         │                 │
         ▼                 ▼
┌────────────────┐  ┌──────────────────┐
│  Delete Items  │  │  Retry with      │
│  from Queue    │  │  Backoff         │
└────────────────┘  │  - Wait 1s       │
                    │  - Wait 2s       │
                    │  - Wait 4s       │
                    └────┬─────────────┘
                         │
                    ┌────┴─────┐
                    │ Retries  │
                    │ Failed?  │
                    └────┬─────┘
                         │ Yes
                         ▼
                  ┌──────────────────┐
                  │  Re-enqueue      │
                  │  Items           │
                  │  (mark failed)   │
                  └──────────────────┘
```

---

## 🛡️ Enforcement Engine Flow

```
┌─────────────────────────────────────────────────────────────┐
│          Enforcement Engine (Background Thread)              │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
         ┌───────────────────┐
         │  Fetch Policies   │
         │  from Backend     │
         │  (every 5 min)    │
         └─────────┬─────────┘
                   │
                   ▼
         ┌───────────────────┐
         │  Cache Policies   │
         │  Locally          │
         └─────────┬─────────┘
                   │
                   ▼
         ┌───────────────────┐
         │  Get Latest CI    │
         │  Data from        │
         │  Collectors       │
         └─────────┬─────────┘
                   │
                   ▼
    ┌────────────────────────────┐
    │  For Each Policy:          │
    │                            │
    │  1. Parse CEL Expression   │
    │  2. Evaluate against Data  │
    │  3. Check Result           │
    └─────────┬──────────────────┘
              │
      ┌───────┴────────┐
      │                │
      ▼                ▼
┌──────────┐    ┌──────────┐
│Compliant?│    │Violated? │
└────┬─────┘    └────┬─────┘
     │               │
     │               ▼
     │      ┌────────────────┐
     │      │  Log Violation │
     │      └────────┬───────┘
     │               │
     │      ┌────────┴────────┐
     │      │  Check Mode:    │
     │      │  - monitor      │
     │      │  - alert        │
     │      │  - remediate    │
     │      │  - block        │
     │      └────────┬────────┘
     │               │
     │      ┌────────┴────────────┐
     │      │                     │
     │      ▼                     ▼
     │  ┌─────────┐         ┌─────────┐
     │  │ Alert   │         │Remediate│
     │  │ Only    │         │ Action  │
     │  └────┬────┘         └────┬────┘
     │       │                   │
     │       │                   ▼
     │       │          ┌────────────────┐
     │       │          │ Execute Action:│
     │       │          │ - Restart svc  │
     │       │          │ - Fix config   │
     │       │          │ - Install pkg  │
     │       │          └────────┬───────┘
     │       │                   │
     │       │                   ▼
     │       │          ┌────────────────┐
     │       │          │ Verify Success │
     │       │          └────────┬───────┘
     │       │                   │
     └───────┴───────────────────┘
             │
             ▼
    ┌────────────────┐
    │ Send Results   │
    │ to Backend     │
    └────────────────┘
```

---

## 🌐 Web UI Request Flow

```
Browser Request
  http://localhost:8080/api/dashboard
        │
        ▼
┌───────────────────┐
│  Go HTTP Server   │
│  (chi router)     │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Middleware Chain │
│  1. Logger        │
│  2. Recoverer     │
│  3. Timeout (60s) │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Auth Middleware  │
│  (BasicAuth)      │
└─────────┬─────────┘
          │
     [Auth Flow - see above]
          │
          ▼
┌───────────────────┐
│  Permission Check │
│  (RequirePermission)│
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Route Handler    │
│  handleDashboard()│
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Get User from    │
│  Context          │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Fetch Data:      │
│  - Agent status   │
│  - Queue stats    │
│  - Collector info │
│  - Policy status  │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Build JSON       │
│  Response         │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Set Headers      │
│  Content-Type:    │
│  application/json │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  Write Response   │
│  Status: 200      │
└─────────┬─────────┘
          │
          ▼
    Return to Browser
```

---

## 🔄 Complete Agent Lifecycle

```
┌──────────────────────────────────────────────────────────────┐
│                        STARTUP                                │
└────────────────────┬─────────────────────────────────────────┘
                     │
                     ▼
         ┌──────────────────┐
         │  Parse CLI Flags │
         │  --config        │
         │  --version       │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Load Config     │
         │  (YAML)          │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Initialize      │
         │  Components      │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Setup Signal    │
         │  Handlers        │
         │  (SIGINT/TERM)   │
         └──────┬───────────┘
                │
                ▼
┌───────────────────────────────────────────────────────────┐
│                     RUNNING STATE                          │
│                                                            │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐          │
│  │ Collectors │  │   Queue    │  │Enforcement │          │
│  │  Running   │  │ Processing │  │   Engine   │          │
│  └────────────┘  └────────────┘  └────────────┘          │
│                                                            │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐          │
│  │ Deployment │  │ API Server │  │  Web UI    │          │
│  │  Manager   │  │ Listening  │  │  Server    │          │
│  └────────────┘  └────────────┘  └────────────┘          │
│                                                            │
│  ┌────────────┐                                           │
│  │ Heartbeat  │ (Every 5 minutes)                         │
│  └────────────┘                                           │
└────────────────────┬──────────────────────────────────────┘
                     │
                     │  Signal Received
                     │  (SIGINT/SIGTERM)
                     │
                     ▼
┌──────────────────────────────────────────────────────────────┐
│                      SHUTDOWN                                 │
└────────────────────┬─────────────────────────────────────────┘
                     │
                     ▼
         ┌──────────────────┐
         │  Cancel Context  │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Stop Scheduler  │
         │  (Wait for jobs) │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Stop Enforcement│
         │  Engine          │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Stop Deployment │
         │  Manager         │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Stop API Server │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Stop Web UI     │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Flush Queue     │
         │  (Send pending)  │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Close Queue DB  │
         └──────┬───────────┘
                │
                ▼
         ┌──────────────────┐
         │  Final Logs      │
         └──────┬───────────┘
                │
                ▼
              EXIT
```

---

## 📈 Scalability & Performance

```
Agent Performance Characteristics:

┌─────────────────────┬──────────────────────────────┐
│ Component           │ Resource Usage               │
├─────────────────────┼──────────────────────────────┤
│ Base Agent          │ ~20 MB RAM, <1% CPU          │
│ Collectors (idle)   │ +5 MB RAM                    │
│ Collectors (active) │ +10-50 MB RAM, 2-10% CPU     │
│ Queue (BoltDB)      │ 5-100 MB disk (variable)     │
│ Web UI Server       │ +10 MB RAM per connection    │
│ Total (typical)     │ 50-100 MB RAM, 5% CPU        │
└─────────────────────┴──────────────────────────────┘

Throughput:
- Collectors: 1-8 concurrent (configurable)
- Queue: 1000+ items/sec
- Transport: 50 items/batch, 2 batches/min
- API: 60 requests/min (rate limited)
```

---

## 🎯 Key Decision Points

```
Collection Frequency Tuning:
┌────────────────────────────────────────┐
│ High-Change Data → Short Interval      │
│ - Processes: @every 30s                │
│ - System metrics: @every 30s           │
│                                        │
│ Low-Change Data → Long Interval        │
│ - Hardware: @every 15m                 │
│ - Software: @every 1h                  │
│ - Certificates: @daily                 │
└────────────────────────────────────────┘

Network Optimization:
┌────────────────────────────────────────┐
│ Compression: ON (gzip)                 │
│ Batch Size: 50 items or 512 KB        │
│ Retry Policy: Exponential backoff     │
│ Connection: Keep-alive, pooled         │
└────────────────────────────────────────┘

Security Trade-offs:
┌────────────────────────────────────────┐
│ Development: OAuth2, localhost-only    │
│ Production: mTLS, certificate pinning  │
│ Enterprise: RBAC, audit logging        │
└────────────────────────────────────────┘
```

This comprehensive flow chart covers all major components and interactions in the CMDB Agent system!
