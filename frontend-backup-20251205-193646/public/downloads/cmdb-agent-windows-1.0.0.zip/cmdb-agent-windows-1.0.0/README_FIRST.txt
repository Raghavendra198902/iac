CMDB Agent for Windows - Quick Start Guide
==========================================

Thank you for downloading CMDB Agent!

Installation Steps:
-------------------
1. Extract this ZIP file to a temporary location
2. Open PowerShell as Administrator
3. Navigate to the extracted folder
4. Run: .\install-windows.ps1

This will:
- Install the agent to C:\Program Files\CMDB Agent\
- Create a Windows service
- Add the agent to your PATH
- Start the service automatically

Configuration:
--------------
Edit config.yaml before installation to customize:
- CMDB server endpoint
- Collection schedules
- Authentication settings
- Web UI settings

After installation, the config file will be at:
C:\Program Files\CMDB Agent\config.yaml

Web UI Access:
--------------
Once installed and started, access the web interface at:
http://localhost:8080

Default credentials:
  Username: admin
  Password: changeme

⚠️ IMPORTANT: Change the default password immediately!

Documentation:
--------------
- README.md - General overview
- docs/WINDOWS_BUILD_GUIDE.md - Detailed Windows instructions
- docs/WEBUI_GUIDE.md - Web UI and API documentation
- docs/FEATURES.md - Complete feature list
- docs/FLOWCHART.md - System architecture diagrams

Quick Commands:
--------------
# Check agent status
cmdb-agent-cli status

# View collected inventory
cmdb-agent-cli inventory list

# Test connectivity
cmdb-agent-cli test connection

# Service management (PowerShell as Admin)
Start-Service CMDBAgent
Stop-Service CMDBAgent
Restart-Service CMDBAgent
Get-Service CMDBAgent

Uninstallation:
---------------
Run (as Administrator):
.\uninstall-windows.ps1

Building MSI Installer (Optional):
----------------------------------
This package includes MSI build files in the 'msi-builder' folder.
To create a professional MSI installer on Windows:

1. Install WiX Toolset 3.11+ from https://wixtoolset.org/
2. Open Command Prompt as Administrator
3. Navigate to the msi-builder folder
4. Run: build-msi.bat

This will create cmdb-agent-1.0.0-x64.msi (approx 15 MB)

The MSI installer provides:
- Professional installation wizard
- Windows Service with auto-start
- PATH environment variable integration
- Start Menu shortcuts
- Desktop shortcut
- Clean uninstaller via Control Panel
- Upgrade support

See msi-builder/BUILD_MSI_GUIDE.md for detailed instructions.

Support:
--------
GitHub: https://github.com/Raghavendra198902/iac
Issues: https://github.com/Raghavendra198902/iac/issues

System Requirements:
--------------------
- Windows Server 2016+ or Windows 10+
- 100 MB RAM minimum
- 50 MB disk space
- Administrator privileges

Version: ${VERSION}
Built: $(date -u '+%Y-%m-%d %H:%M:%S UTC')
