#!/bin/bash
set -e

echo "Uninstalling CMDB Agent..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run with sudo"
    exit 1
fi

# Stop and unload service
launchctl stop com.cmdb.agent || true
launchctl unload /Library/LaunchDaemons/com.cmdb.agent.plist || true
rm -f /Library/LaunchDaemons/com.cmdb.agent.plist

# Remove binaries
rm -f /usr/local/bin/cmdb-agent
rm -f /usr/local/bin/cmdb-agent-cli

echo ""
echo "✅ CMDB Agent uninstalled"
echo ""
echo "Configuration and data preserved in:"
echo "  /usr/local/etc/cmdb-agent/"
echo "  /usr/local/var/cmdb-agent/"
echo "  /usr/local/var/log/cmdb-agent/"
echo ""
echo "To remove all data, run:"
echo "  sudo rm -rf /usr/local/etc/cmdb-agent /usr/local/var/cmdb-agent /usr/local/var/log/cmdb-agent"
