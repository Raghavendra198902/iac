#!/bin/bash
set -e

echo "Installing CMDB Agent for macOS..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run with sudo"
    exit 1
fi

INSTALL_DIR="/usr/local/cmdb-agent"
BIN_DIR="/usr/local/bin"
CONFIG_DIR="/usr/local/etc/cmdb-agent"
DATA_DIR="/usr/local/var/cmdb-agent"
LOG_DIR="/usr/local/var/log/cmdb-agent"

# Create directories
mkdir -p "$INSTALL_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$DATA_DIR"
mkdir -p "$LOG_DIR"

# Copy binaries
cp cmdb-agent "$BIN_DIR/"
cp cmdb-agent-cli "$BIN_DIR/"
chmod +x "$BIN_DIR/cmdb-agent" "$BIN_DIR/cmdb-agent-cli"

# Copy configuration
if [ ! -f "$CONFIG_DIR/config.yaml" ]; then
    cp config.yaml "$CONFIG_DIR/config.yaml"
    echo "Config installed to $CONFIG_DIR/config.yaml"
else
    echo "Config already exists, skipping"
fi

# Install LaunchDaemon
cp LaunchDaemons/com.cmdb.agent.plist /Library/LaunchDaemons/
chmod 644 /Library/LaunchDaemons/com.cmdb.agent.plist
chown root:wheel /Library/LaunchDaemons/com.cmdb.agent.plist

# Load and start service
launchctl load /Library/LaunchDaemons/com.cmdb.agent.plist
launchctl start com.cmdb.agent

echo ""
echo "✅ CMDB Agent installed successfully!"
echo ""
echo "Service status:"
launchctl list | grep cmdb || echo "Service not found in launchctl list"
echo ""
echo "Configuration: $CONFIG_DIR/config.yaml"
echo "Logs: $LOG_DIR/agent.log"
echo "Data: $DATA_DIR"
echo ""
echo "Useful commands:"
echo "  sudo launchctl start com.cmdb.agent"
echo "  sudo launchctl stop com.cmdb.agent"
echo "  sudo launchctl unload /Library/LaunchDaemons/com.cmdb.agent.plist"
echo "  cmdb-agent-cli status"
echo "  cmdb-agent-cli inventory list"
echo "  tail -f $LOG_DIR/agent.log"
