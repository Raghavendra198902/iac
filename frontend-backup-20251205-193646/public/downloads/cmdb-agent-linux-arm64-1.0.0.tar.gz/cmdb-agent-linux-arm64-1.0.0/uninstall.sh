#!/bin/bash
set -e

echo "Uninstalling CMDB Agent..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root or with sudo"
    exit 1
fi

# Stop and disable service
systemctl stop cmdb-agent.service || true
systemctl disable cmdb-agent.service || true
rm -f /etc/systemd/system/cmdb-agent.service
systemctl daemon-reload

# Remove binaries
rm -f /usr/local/bin/cmdb-agent
rm -f /usr/local/bin/cmdb-agent-cli

echo ""
echo "✅ CMDB Agent uninstalled"
echo ""
echo "Configuration and data preserved in:"
echo "  /etc/cmdb-agent/"
echo "  /var/lib/cmdb-agent/"
echo "  /var/log/cmdb-agent/"
echo ""
echo "To remove all data, run:"
echo "  sudo rm -rf /etc/cmdb-agent /var/lib/cmdb-agent /var/log/cmdb-agent"
