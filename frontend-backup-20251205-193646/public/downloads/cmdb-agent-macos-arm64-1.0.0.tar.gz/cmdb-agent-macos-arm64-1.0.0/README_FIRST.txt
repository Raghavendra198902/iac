CMDB Agent for macOS - Quick Start Guide
========================================

Version: 1.0.0
Architecture: Apple Silicon (arm64)
Built: 2025-12-03 05:42:37 UTC

Installation Steps:
-------------------
1. Extract this archive to a temporary location
2. Open Terminal
3. Run: sudo ./install.sh

This will:
- Install binaries to /usr/local/bin/
- Create LaunchDaemon service
- Set up configuration in /usr/local/etc/cmdb-agent/
- Start the agent automatically

Configuration:
--------------
Edit /usr/local/etc/cmdb-agent/config.yaml to customize:
- CMDB server endpoint
- Collection schedules
- Authentication settings
- Web UI settings

Web UI Access:
--------------
Once installed and started, access at:
http://localhost:8080

Default credentials:
  Username: admin
  Password: changeme

⚠️ IMPORTANT: Change the default password immediately!

Quick Commands:
--------------
# Service management
sudo launchctl start com.cmdb.agent
sudo launchctl stop com.cmdb.agent
sudo launchctl unload /Library/LaunchDaemons/com.cmdb.agent.plist
sudo launchctl load /Library/LaunchDaemons/com.cmdb.agent.plist

# Agent CLI
cmdb-agent-cli status
cmdb-agent-cli inventory list
cmdb-agent-cli test connection

# View logs
tail -f /usr/local/var/log/cmdb-agent/agent.log

Uninstallation:
---------------
Run: sudo ./uninstall.sh

System Requirements:
--------------------
- macOS 10.15+ (Catalina or later)
- Apple Silicon processor
- 100 MB RAM minimum
- 50 MB disk space

Compatibility:
--------------
Intel Macs (x86_64): Use amd64 package
Apple Silicon (M1/M2/M3): Use arm64 package

Support:
--------
GitHub: https://github.com/Raghavendra198902/iac
Issues: https://github.com/Raghavendra198902/iac/issues
