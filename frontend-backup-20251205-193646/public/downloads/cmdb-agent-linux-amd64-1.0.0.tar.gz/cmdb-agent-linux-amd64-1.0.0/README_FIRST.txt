CMDB Agent for Linux - Quick Start Guide
========================================

Version: 1.0.0
Architecture: amd64
Built: 2025-12-03 05:42:21 UTC

Installation Steps:
-------------------
1. Extract this archive to a temporary location
2. Open a terminal
3. Run as root: sudo ./install.sh

This will:
- Install binaries to /usr/local/bin/
- Create systemd service
- Set up configuration in /etc/cmdb-agent/
- Start the agent automatically

Configuration:
--------------
Edit /etc/cmdb-agent/config.yaml to customize:
- CMDB server endpoint
- Collection schedules
- Authentication settings
- Web UI settings

Web UI Access:
--------------
Once installed and started, access at:
http://localhost:8080

Default credentials:
  Username: admin
  Password: changeme

⚠️ IMPORTANT: Change the default password immediately!

Quick Commands:
--------------
# Service management
sudo systemctl start cmdb-agent
sudo systemctl stop cmdb-agent
sudo systemctl restart cmdb-agent
sudo systemctl status cmdb-agent

# Agent CLI
cmdb-agent-cli status
cmdb-agent-cli inventory list
cmdb-agent-cli test connection

# View logs
sudo journalctl -u cmdb-agent -f
tail -f /var/log/cmdb-agent/agent.log

Uninstallation:
---------------
Run as root: sudo ./uninstall.sh

System Requirements:
--------------------
- Linux kernel 3.10+
- systemd (for service management)
- 100 MB RAM minimum
- 50 MB disk space

Support:
--------
GitHub: https://github.com/Raghavendra198902/iac
Issues: https://github.com/Raghavendra198902/iac/issues
