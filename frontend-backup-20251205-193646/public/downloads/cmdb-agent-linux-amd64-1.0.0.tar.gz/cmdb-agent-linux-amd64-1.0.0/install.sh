#!/bin/bash
set -e

echo "Installing CMDB Agent..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root or with sudo"
    exit 1
fi

INSTALL_DIR="/opt/cmdb-agent"
BIN_DIR="/usr/local/bin"
CONFIG_DIR="/etc/cmdb-agent"
DATA_DIR="/var/lib/cmdb-agent"
LOG_DIR="/var/log/cmdb-agent"

# Create directories
mkdir -p "$INSTALL_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$DATA_DIR"
mkdir -p "$LOG_DIR"

# Copy binaries
cp cmdb-agent "$BIN_DIR/"
cp cmdb-agent-cli "$BIN_DIR/"
chmod +x "$BIN_DIR/cmdb-agent" "$BIN_DIR/cmdb-agent-cli"

# Copy configuration
if [ ! -f "$CONFIG_DIR/config.yaml" ]; then
    cp config.yaml "$CONFIG_DIR/config.yaml"
    echo "Config installed to $CONFIG_DIR/config.yaml"
else
    echo "Config already exists, skipping"
fi

# Install systemd service
if [ -d /etc/systemd/system ]; then
    cp systemd/cmdb-agent.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable cmdb-agent.service
    systemctl start cmdb-agent.service
    echo "✅ Systemd service installed and started"
fi

# Create cmdb-agent user if doesn't exist
if ! id cmdb-agent &>/dev/null; then
    useradd -r -s /bin/false -d "$DATA_DIR" cmdb-agent
fi

# Set permissions
chown -R cmdb-agent:cmdb-agent "$DATA_DIR" "$LOG_DIR"

echo ""
echo "✅ CMDB Agent installed successfully!"
echo ""
echo "Service status:"
systemctl status cmdb-agent.service --no-pager || true
echo ""
echo "Configuration: $CONFIG_DIR/config.yaml"
echo "Logs: $LOG_DIR"
echo "Data: $DATA_DIR"
echo ""
echo "Useful commands:"
echo "  sudo systemctl start cmdb-agent"
echo "  sudo systemctl stop cmdb-agent"
echo "  sudo systemctl status cmdb-agent"
echo "  cmdb-agent-cli status"
echo "  cmdb-agent-cli inventory list"
